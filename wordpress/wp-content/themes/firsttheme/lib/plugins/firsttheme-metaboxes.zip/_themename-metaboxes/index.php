<?php
/*
Plugin Name: firsttheme metaboxes
Plugin URI:
Description: Adding Metaboxes for firsttheme
Version: 1.0.0
Author: Chiahong Chou
Author URI: https://chunhongweb.com
License: MIT
Text Domain: firsttheme-pluginname
Domain Path: /languages
*/

if (!defined('WPINC')) {
    die();
}

include_once 'includes/metaboxes.php';
include_once 'includes/enqueue-assets.php';

?>
